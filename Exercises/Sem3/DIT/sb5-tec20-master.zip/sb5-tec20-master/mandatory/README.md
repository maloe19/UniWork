Mandatory assignments
---------------------

This sub-directory contain the mandatory assignments

- [POST-request.md](POST-request.md) - Deadline: October 23, 23:59:00
- ...
