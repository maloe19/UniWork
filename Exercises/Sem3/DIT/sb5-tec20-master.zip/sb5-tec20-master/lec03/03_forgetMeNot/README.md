JSON and localStorage
---------------------

This directory contains examples of using JS's JSON API and `localStorage`.
