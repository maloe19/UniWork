AJAX request with jQuery
------------------------

This directory contains an example of an asynchronous
request to a local webserver on localhost using jQuery.

To run [example.html](example.html)
start an Nginx webserver inside docker with
```
 $ docker-compose up
```
from *this* directory.

Then access http://localhost:8080/example.html in a browser
