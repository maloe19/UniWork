Object-oriented programming in JS
---------------------------------

This directory contains the examples from the 'Object-oriented programming in JS'
part of the lecture.
