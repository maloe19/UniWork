Poor man's modules example
--------------------------

This directory contains examples of how a module system can be mimicked using an older JavaScript version.

The idea is to use an anonymous function and apply (call) it immediately.