A minimal TypeScript example
----------------------------

This directory contains a minimal TypeScript example program in [15-greeter.ts](15-greeter.js).

Compile it with:
```
 $ tsc 15-greeter.ts
```
which should produce an output `15-greeter.js` file (used by [15-greeter.html](15-greeter.html))