A minimal npm example
---------------------

This directory contains a minimal Node/npm example.

[package.json](package.json) describes the project and a dependency on the upper-case package  
[main.js](main.js) contains the code which uses the upper-case package

To install the dependency (upper-case):
```
$ npm install
```
Now you can run the program:
```
$ node main.js hello
```