A CommonJS module example
-------------------------

This directory contains an example of CommonJS modules.

[statecjs.js](statecjs.js) contains the module's code  
[state-use-cjs.js](state-use-cjs.js) imports and calls the module (server-side) 
[state-use-cjs2.js](state-use-cjs2.js) imports the module with destructive assignment and calls it (server-side)

You can run these from *this* directory with:
```
 $ node state-use-cjs.js
```
