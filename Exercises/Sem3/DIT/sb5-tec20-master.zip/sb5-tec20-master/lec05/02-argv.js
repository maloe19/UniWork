console.log(process.argv);
process.exit(0);