let user: string = prompt("What is your name?");
document.body.textContent = Math.sqrt(user);