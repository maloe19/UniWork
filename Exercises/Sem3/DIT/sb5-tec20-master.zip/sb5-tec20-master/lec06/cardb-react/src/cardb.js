import React from 'react';

class CarDB extends React.Component{
    render() {
        return(
            <div>
                <h1>Car Database, React Edition</h1>
                <p>car-list Works!</p>
            </div>
            
        );
    }
};

export default CarDB;