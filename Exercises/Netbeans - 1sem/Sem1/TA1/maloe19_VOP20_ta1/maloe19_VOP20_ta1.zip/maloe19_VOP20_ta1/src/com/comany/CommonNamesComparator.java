package com.comany;

import java.util.Comparator;

    /**
     * VOP ReEksamen F16
     * Kodeskelet til opgave 4c
     * @author erso
     */
    public class CommonNamesComparator implements Comparator<CommonName> {

        @Override
        public int compare(CommonName o1, CommonName o2) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

    }
