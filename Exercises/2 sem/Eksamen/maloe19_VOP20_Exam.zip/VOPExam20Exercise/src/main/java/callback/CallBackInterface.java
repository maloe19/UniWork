package callback;

import java.util.Map;

public interface CallBackInterface {

    void updateStatus(String message);

    void updateView();


}
