package app;

import javafx.event.ActionEvent;
import javafx.stage.FileChooser;
import sprinter.ReadCSV;
import java.io.File;

public class PrimaryController {
    private File selectedFile;
    private ReadCSV readCSV;



    public void readFile(ActionEvent actionEvent) {
//        FileChooser fileChooser = new FileChooser();
//        selectedFile = fileChooser.showOpenDialog(null);
//        if (selectedFile!=null){
//            readCSV = new ReadCSV(this, selectedFile);
//            Thread t = new Thread(readCSV);
//            t.isDaemon();
//            t.start();
//        }

    }

    public void sortAction(ActionEvent actionEvent) {
        //TODO

    }
}
