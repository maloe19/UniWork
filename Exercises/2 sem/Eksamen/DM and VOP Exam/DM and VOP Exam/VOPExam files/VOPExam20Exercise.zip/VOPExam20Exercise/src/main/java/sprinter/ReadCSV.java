package sprinter;

import callback.CallBackInterface;

import java.io.File;
import java.util.*;

public class ReadCSV implements Runnable {
    private CallBackInterface callBack;
    private File file;
    private Map<String, Set<Sprinter>> map;

    public ReadCSV(String fileName){
        callBack = new CallBackInterface() {
            @Override
            public void updateStatus(String message) {
                System.out.println(message);
            }

            @Override
            public void updateView() {
                System.out.println(map);
            }
        };
        this.map = new TreeMap();
        this.file = new File(fileName);

    }

    public ReadCSV(CallBackInterface callBack, File file) {
        this.map = new TreeMap();
        this.file = file;
        this.callBack = callBack;

    }

    public void run() {
        //TODO
    }

    private void readFile() {
        //TODO
    }

    public static void main(String[] args) {
        ReadCSV readCSV = new ReadCSV("challenge.csv");
        Thread t = new Thread(readCSV);
        t.isDaemon();
        t.start();
    }

}