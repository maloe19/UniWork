package sprinter;

import java.util.Set;
import java.util.TreeSet;

public class Sprinter implements Comparable<Sprinter>{

//    @Override
//    public String toString() {
//        return String.format("%d \t \t %s \t \t %s \t \t %s \t \t %d \n", getRaceNo(), getCountry(), getoTime(), gethTime(), getoPosition());
//    }

    @Override
    public int compareTo(Sprinter o) {
        //TODO
        return 0;
    }

    public static void main(String[] args) {
////        Task 1a
//        Set<Sprinter> sprinters1 = new TreeSet();
//        sprinters1.add(new Sprinter(21080, 1, 1, "Kenya", "2:12:12", "1:04:48"));
//        sprinters1.add(new Sprinter(14, 2, 2, "Kenya", "2:12:14", "1:04:48"));
//        sprinters1.add(new Sprinter(2, 3, 3, "Ethiopia", "2:12:20", "1:04:49"));
//        System.out.println(sprinters1);

////        Task 1b
//        Set<Sprinter> sprinters2 = new TreeSet(new ComparatorHalfTime());
//        sprinters2.addAll(sprinters1);
//        System.out.println(sprinters2);
//
//        Set<Sprinter> sprinters3 = new TreeSet(new ComparatorPosition());
//        sprinters3.addAll(sprinters1);
//        System.out.println(sprinters3);
    }

}
